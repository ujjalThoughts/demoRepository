package com.crm.pages;

import com.crm.base.TestBase;

public class SignUpPage extends TestBase{

}
