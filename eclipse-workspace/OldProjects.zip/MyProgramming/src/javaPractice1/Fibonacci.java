package javaPractice1;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String args[])
	{
	String s="Sachin";
	String s1="Sachin";
	String s2=new String("Tendulkar");
	
	System.out.println(s1+s2);
	
	
}
}
