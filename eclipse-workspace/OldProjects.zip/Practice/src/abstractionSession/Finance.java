package abstractionSession;

public class Finance {

	public void stock()
	{
		System.out.println("Finance---Stock");
	}
}
