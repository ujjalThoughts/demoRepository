package abstractionSession;

public interface RBI {

 public void educationLoan();
	
	public void homeLoan();
	
	public void carLoan();
}
