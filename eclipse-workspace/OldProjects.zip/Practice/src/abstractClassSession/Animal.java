package abstractClassSession;

public abstract class Animal {

	// 0% Abstraction:::
	public void eat() {
		System.out.println("Animal---Eat");
	}
}
