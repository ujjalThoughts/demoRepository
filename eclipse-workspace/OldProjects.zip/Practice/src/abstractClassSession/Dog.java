package abstractClassSession;

public class Dog extends Animal{

	public static void main(String[] args) {
		
		Dog d=new Dog();
		d.eat(); 

	}

}
