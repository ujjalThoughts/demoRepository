package interfaceSession;

public interface BrazilBank {

	public void mutualFund();
}
