package Amazon;

import org.testng.annotations.Test;

public class practice1Test {

  @Test
  public void main() {
    throw new RuntimeException("Test not implemented");
  }
}
